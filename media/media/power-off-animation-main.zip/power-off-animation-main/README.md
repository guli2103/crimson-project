<div align="center">

# Power off Animation | Crimson

<img src="admin/base.png">

### by <a href="https://github.com/shahnozahaydarova">Shakhnoza Haydarova</a>

</div>