<div align="center">

# CSS Parallax Orbs | Crimson
<img src="admin/base.png">

### by <a href="https://github.com/shahnozahaydarova">Shakhnoza Haydarova</a>

</div>