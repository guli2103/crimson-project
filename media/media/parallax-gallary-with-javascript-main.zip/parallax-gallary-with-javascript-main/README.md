<div align="center">

# Parallax Gallary with JavaScript | Crimson
<img src="admin/base.png">

### by <a href="https://github.com/shahnozahaydarova">Shakhnoza Haydarova</a>

</div>
